package com.example.gobaltvisual.gui;

import com.example.gobaltvisual.gui.widgets.GVButton;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class GobaltVisualScreen extends class_437 {
    private static final int WINDOW_WIDTH = 580;
    private static final int WINDOW_HEIGHT = 240;
    private static final int BUTTON_WIDTH = 130;
    private static final int BUTTON_HEIGHT = 16;
    private static final int BUTTON_GAP = 18;

    private int windowX;
    private int windowY;

    public GobaltVisualScreen() {
        super(class_2561.method_43470("Gobalt Visual"));
    }

    @Override
    protected void method_25426() {
        this.windowX = (this.field_22789 - WINDOW_WIDTH) / 2;
        this.windowY = (this.field_22790 - WINDOW_HEIGHT) / 2;
        createButtons();
    }

    private void createButtons() {
        this.method_37067();

        int cx = this.windowX + WINDOW_WIDTH / 2;
        int cy = this.windowY + WINDOW_HEIGHT / 2 - 10;
        int y1 = cy - 20;

        // ===== ПВП (6 функций) =====
        int x1 = cx - 200;
        this.method_37063(new GVButton(x1, y1 + 20, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("🎯 Хитбоксы"), 
                () -> field_22787.method_1507(new SubmenuHitboxes(this))));
        this.method_37063(new GVButton(x1, y1 + 38, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("🎯 Прицел"), 
                () -> sendMessage("🎯 Прицел открыт!")));
        this.method_37063(new GVButton(x1, y1 + 56, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("☠️ Kill Streak"), 
                () -> sendMessage("☠️ Kill Streak открыт!")));
        this.method_37063(new GVButton(x1, y1 + 74, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("👟 Отбрасывание"), 
                () -> sendMessage("👟 Отбрасывание открыто!")));

        // ===== ВИЗУАЛ (6 функций) =====
        int x2 = cx - 60;
        this.method_37063(new GVButton(x2, y1 + 20, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("☀️ Гамма"), 
                () -> sendMessage("☀️ Гамма открыта!")));
        this.method_37063(new GVButton(x2, y1 + 38, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("🌤️ Небо"), 
                () -> sendMessage("🌤️ Небо открыто!")));
        this.method_37063(new GVButton(x2, y1 + 56, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("🖐️ Руки"), 
                () -> sendMessage("🖐️ Руки открыты!")));
        this.method_37063(new GVButton(x2, y1 + 74, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("🌀 Шейдеры"), 
                () -> sendMessage("🌀 Шейдеры открыты!")));

        // ===== ИНТЕРФЕЙС (6 функций) =====
        int x3 = cx + 80;
        this.method_37063(new GVButton(x3, y1 + 20, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("📈 FPS"), 
                () -> sendMessage("📈 FPS открыт!")));
        this.method_37063(new GVButton(x3, y1 + 38, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("📍 Координаты"), 
                () -> sendMessage("📍 Координаты открыты!")));
        this.method_37063(new GVButton(x3, y1 + 56, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("🧭 Компас"), 
                () -> sendMessage("🧭 Компас открыт!")));
        this.method_37063(new GVButton(x3, y1 + 74, BUTTON_WIDTH, BUTTON_HEIGHT, 
                class_2561.method_43470("🕐 Часы"), 
                () -> sendMessage("🕐 Часы открыты!")));

        // Закрыть
        this.method_37063(new GVButton(
            this.windowX + WINDOW_WIDTH / 2 - 30,
            this.windowY + WINDOW_HEIGHT - 22,
            60, 16,
            class_2561.method_43470("✕ Закрыть"),
            0xFFFF4444,
            () -> this.method_25419()
        ));
    }

    private void sendMessage(String msg) {
        if (field_22787.field_1724 != null) {
            field_22787.field_1724.method_7353(class_2561.method_43470("§5[GV] " + msg), false);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xDD0A0510);

        int wx = this.windowX;
        int wy = this.windowY;
        int ww = WINDOW_WIDTH;
        int wh = WINDOW_HEIGHT;

        drawRoundedRect(context, wx, wy, ww, wh, 12, 0xCC1A0A2A);
        drawRoundedBorder(context, wx, wy, ww, wh, 12, 0x8844CCFF);
        drawRoundedBorder(context, wx + 2, wy + 2, ww - 4, wh - 4, 10, 0x444466AA);

        for (int i = 0; i < 25; i++) {
            int alpha = 18 - (int)(i * 0.5);
            context.method_25294(wx + 15, wy + 4 + i, wx + ww - 15, wy + 5 + i, (alpha << 24) | 0x9966FF);
        }

        context.method_51439(
            field_22793,
            class_2561.method_43470("⚡ GOBALT VISUAL").method_27695(class_124.field_1067, class_124.field_1076),
            wx + 16, wy + 8, 0xCC99FF, false
        );

        context.method_51439(
            field_22793,
            class_2561.method_43470("v2.0 • нажми P").method_27692(class_124.field_1063),
            wx + 16, wy + 20, 0x666688, false
        );

        context.method_25294(wx + 14, wy + 32, wx + ww - 14, wy + 33, 0x334466AA);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void drawRoundedRect(class_332 context, int x, int y, int w, int h, int r, int color) {
        context.method_25294(x + r, y, x + w - r, y + h, color);
        context.method_25294(x, y + r, x + w, y + h - r, color);
        context.method_25294(x, y, x + r, y + r, color);
        context.method_25294(x + w - r, y, x + w, y + r, color);
        context.method_25294(x, y + h - r, x + r, y + h, color);
        context.method_25294(x + w - r, y + h - r, x + w, y + h, color);
    }

    private void drawRoundedBorder(class_332 context, int x, int y, int w, int h, int r, int color) {
        context.method_25294(x + r, y, x + w - r, y + 1, color);
        context.method_25294(x + r, y + h - 1, x + w - r, y + h, color);
        context.method_25294(x, y + r, x + 1, y + h - r, color);
        context.method_25294(x + w - 1, y + r, x + w, y + h - r, color);
        context.method_25294(x, y, x + r, y + 1, color);
        context.method_25294(x + w - r, y, x + w, y + 1, color);
        context.method_25294(x, y + h - 1, x + r, y + h, color);
        context.method_25294(x + w - r, y + h - 1, x + w, y + h, color);
    }
}
