package com.example.gobaltvisual.gui;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class SubmenuPvP extends class_437 {
    private final class_437 parent;

    public SubmenuPvP(class_437 parent) {
        super(class_2561.method_43470("ПВП - Gobalt Visual"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2 - 80;

        // ===== ЗАГОЛОВОК =====
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("⚔️ НАСТРОЙКИ ПВП").method_27695(class_124.field_1067, class_124.field_1075),
                button -> {}
        ).method_46434(cx - 90, cy - 20, 180, 20).method_46431());

        // ===== ХИТБОКСЫ =====
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("🎯 Хитбоксы").method_27692(class_124.field_1060),
                button -> {
                    if (field_22787.field_1724 != null) {
                        field_22787.field_1724.method_7353(class_2561.method_43470("§a[GV] 🎯 Настройка хитбоксов открыта!"), false);
                    }
                }
        ).method_46434(cx - 80, cy + 20, 160, 22).method_46431());

        // ===== ПРИЦЕЛ =====
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("🎯 Прицел").method_27692(class_124.field_1065),
                button -> {
                    if (field_22787.field_1724 != null) {
                        field_22787.field_1724.method_7353(class_2561.method_43470("§6[GV] 🎯 Настройка прицела открыта!"), false);
                    }
                }
        ).method_46434(cx - 80, cy + 50, 160, 22).method_46431());

        // ===== KILL STREAK =====
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("☠️ Kill Streak").method_27692(class_124.field_1061),
                button -> {
                    if (field_22787.field_1724 != null) {
                        field_22787.field_1724.method_7353(class_2561.method_43470("§c[GV] ☠️ Настройка Kill Streak открыта!"), false);
                    }
                }
        ).method_46434(cx - 80, cy + 80, 160, 22).method_46431());

        // ===== ОТБРАСЫВАНИЕ =====
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("👟 Отбрасывание").method_27692(class_124.field_1076),
                button -> {
                    if (field_22787.field_1724 != null) {
                        field_22787.field_1724.method_7353(class_2561.method_43470("§d[GV] 👟 Настройка отбрасывания открыта!"), false);
                    }
                }
        ).method_46434(cx - 80, cy + 110, 160, 22).method_46431());

        // ===== КНОПКА НАЗАД =====
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("🔙 Назад").method_27692(class_124.field_1080),
                button -> field_22787.method_1507(parent)
        ).method_46434(cx - 80, cy + 160, 160, 22).method_46431());
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xCC0A192F);

        int wx = this.field_22789 / 2 - 110;
        int wy = this.field_22790 / 2 - 120;
        int ww = 220;
        int wh = 280;

        context.method_25294(wx, wy, wx + ww, wy + wh, 0xCC1A2A4A);
        context.method_49601(wx, wy, ww, wh, 0xFF00D4FF);
        context.method_25294(wx + 10, wy + 22, wx + ww - 10, wy + 23, 0xFF00D4FF);

        context.method_51439(field_22793,
                class_2561.method_43470("v2.0 (a0)").method_27692(class_124.field_1063),
                wx + ww - 50, wy + wh - 12, 0xFF666666, false);

        super.method_25394(context, mouseX, mouseY, delta);
    }
}
