package com.example.gobaltvisual.gui.widgets;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_357;

public class ColorSlider extends class_357 {
    private final Consumer<Float> consumer;
    private final float min, max;

    public ColorSlider(int x, int y, int w, int h, class_2561 text, float min, float max, float current, Consumer<Float> consumer) {
        super(x, y, w, h, text, current);
        this.min = min;
        this.max = max;
        this.consumer = consumer;
        this.field_22753 = (current - min) / (max - min);
        method_25346();
    }

    @Override
    protected void method_25346() {
        float val = min + (max - min) * (float) this.field_22753;
        this.method_25355(class_2561.method_43470(this.method_25369().getString() + ": " + String.format("%.2f", val)));
    }

    @Override
    protected void method_25344() {
        float val = min + (max - min) * (float) this.field_22753;
        consumer.accept(val);
    }
}