package com.example.gobaltvisual.gui.widgets;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public class GVButton extends class_339 {
    private final Runnable action;
    private int color = 0xFFFFFFFF;
    private boolean hovered = false;

    public GVButton(int x, int y, int width, int height, class_2561 message, Runnable action) {
        super(x, y, width, height, message);
        this.action = action;
    }

    public GVButton(int x, int y, int width, int height, class_2561 message, int color, Runnable action) {
        super(x, y, width, height, message);
        this.action = action;
        this.color = color;
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        this.field_22762 = mouseX >= this.method_46426() && mouseX <= this.method_46426() + this.field_22758 &&
                       mouseY >= this.method_46427() && mouseY <= this.method_46427() + this.field_22759;

        int x = this.method_46426();
        int y = this.method_46427();
        int w = this.field_22758;
        int h = this.field_22759;

        // Фон
        int bgColor = 0x33000000;
        if (field_22762) {
            bgColor = 0x66000000;
        }
        context.method_25294(x, y, x + w, y + h, bgColor);

        // Левая полоска при наведении
        if (field_22762) {
            context.method_25294(x, y, x + 2, y + h, 0xCC6633FF);
        }

        // Текст
        int textColor = field_22762 ? 0xFFFFFFFF : 0xCCCCCCCC;
        String text = this.method_25369().getString();
        context.method_51439(class_310.method_1551().field_1772,
                class_2561.method_43470(text).method_27692(class_124.field_1068),
                x + 8, y + (h - 8) / 2, textColor, false);

        // Стрелка при наведении
        if (field_22762) {
            context.method_51439(class_310.method_1551().field_1772,
                    class_2561.method_43470("›").method_27692(class_124.field_1076),
                    x + w - 12, y + (h - 8) / 2, 0xFFFF55FF, false);
        }
    }

    @Override
    protected void method_47399(class_6382 builder) {
        // Пустая реализация для совместимости
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        if (action != null) {
            action.run();
        }
    }
}
