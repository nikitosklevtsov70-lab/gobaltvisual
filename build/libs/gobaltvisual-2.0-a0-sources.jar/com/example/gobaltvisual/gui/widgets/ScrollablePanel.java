package com.example.gobaltvisual.gui.widgets;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_8021;

public class ScrollablePanel {
    private final int x, y, width, height;
    private final List<class_339> widgets = new ArrayList<>();
    private int scrollOffset = 0;
    private int maxScroll = 0;
    private final int itemHeight = 20;
    private final int gap = 2;

    public ScrollablePanel(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void addWidget(class_339 widget) {
        widgets.add(widget);
        recalculateScroll();
    }

    public void addWidgets(List<class_339> widgets) {
        this.widgets.addAll(widgets);
        recalculateScroll();
    }

    public void clear() {
        widgets.clear();
        scrollOffset = 0;
        maxScroll = 0;
    }

    private void recalculateScroll() {
        int totalHeight = widgets.size() * (itemHeight + gap);
        maxScroll = Math.max(0, totalHeight - height + 20);
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        // Рамка панели
        context.method_25294(x, y, x + width, y + height, 0xCC0A192F);
        context.method_49601(x, y, width, height, 0xFF00D4FF);

        // Обрезаем область рисования (для скролла)
        context.method_44379(x + 1, y + 1, x + width - 1, y + height - 1);

        int currentY = y + 4 - scrollOffset;
        for (class_8021 widget : widgets) {
            if (widget instanceof class_339) {
                class_339 w = (class_339) widget;
                w.method_46421(x + 4);
                w.method_46419(currentY);
                w.method_25358(width - 8);
                w.method_53533(itemHeight);
                w.method_25394(context, mouseX, mouseY, delta);
                currentY += itemHeight + gap;
            }
        }

        context.method_44380();

        // Индикатор скролла (полоса справа)
        if (maxScroll > 0) {
            int scrollBarHeight = Math.max(20, height * height / (height + maxScroll));
            int scrollBarY = y + (height - scrollBarHeight) * scrollOffset / maxScroll;
            context.method_25294(x + width - 4, scrollBarY, x + width - 1, scrollBarY + scrollBarHeight, 0xFF00D4FF);
        }
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height) {
            scrollOffset = (int) Math.max(0, Math.min(maxScroll, scrollOffset - amount * 10));
            return true;
        }
        return false;
    }

    public List<class_339> getWidgets() {
        return widgets;
    }

    public void setScrollOffset(int offset) {
        this.scrollOffset = Math.max(0, Math.min(maxScroll, offset));
    }
}