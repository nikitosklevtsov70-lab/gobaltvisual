package com.example.gobaltvisual.gui;

import com.example.gobaltvisual.config.HitboxesConfig;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class SubmenuHitboxes extends class_437 {
    private final class_437 parent;

    public SubmenuHitboxes(class_437 parent) {
        super(class_2561.method_43470("Настройка хитбоксов"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        // Заголовок
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("🎯 НАСТРОЙКА ХИТБОКСОВ").method_27695(class_124.field_1067, class_124.field_1075),
                button -> {}
        ).method_46434(cx - 80, cy - 80, 160, 20).method_46431());

        // Кнопка ВКЛ/ВЫКЛ
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(HitboxesConfig.data.enabled ? "🟢 Включены" : "🔴 Выключены")
                        .method_27692(HitboxesConfig.data.enabled ? class_124.field_1060 : class_124.field_1061),
                button -> {
                    HitboxesConfig.data.enabled = !HitboxesConfig.data.enabled;
                    HitboxesConfig.save();
                    field_22787.method_1507(new SubmenuHitboxes(parent));
                }
        ).method_46434(cx - 60, cy - 40, 120, 20).method_46431());

        // Кнопка "Назад"
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("🔙 Назад").method_27692(class_124.field_1080),
                button -> field_22787.method_1507(parent)
        ).method_46434(cx - 40, cy + 40, 80, 20).method_46431());
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xCC0A192F);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
