package com.example.gobaltvisual.mixin;

import com.example.gobaltvisual.config.HitboxesConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class MixinWorldRenderer {
    
    // ПРАВИЛЬНАЯ СИГНАТУРА ДЛЯ 1.21.1
    @Inject(method = "renderEntity", at = @At("HEAD"))
    private void renderHitbox(class_1297 entity, double x, double y, double z, float yaw, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        HitboxesConfig.HitboxesData cfg = HitboxesConfig.data;
        if (!cfg.enabled) return;
        if (entity == net.minecraft.class_310.method_1551().field_1724) return;
        
        class_238 box = entity.method_5829();
        float x1 = (float) (box.field_1323 - x);
        float y1 = (float) (box.field_1322 - y);
        float z1 = (float) (box.field_1321 - z);
        float x2 = (float) (box.field_1320 - x);
        float y2 = (float) (box.field_1325 - y);
        float z2 = (float) (box.field_1324 - z);
        
        float r = cfg.red;
        float g = cfg.green;
        float b = cfg.blue;
        float a = cfg.alpha;
        
        class_4588 consumer = vertexConsumers.getBuffer(class_1921.method_49042());
        Matrix4f matrix = matrices.method_23760().method_23761();
        
        drawLine(consumer, matrix, x1, y1, z1, x2, y1, z1, r, g, b, a);
        drawLine(consumer, matrix, x2, y1, z1, x2, y1, z2, r, g, b, a);
        drawLine(consumer, matrix, x2, y1, z2, x1, y1, z2, r, g, b, a);
        drawLine(consumer, matrix, x1, y1, z2, x1, y1, z1, r, g, b, a);
        
        drawLine(consumer, matrix, x1, y2, z1, x2, y2, z1, r, g, b, a);
        drawLine(consumer, matrix, x2, y2, z1, x2, y2, z2, r, g, b, a);
        drawLine(consumer, matrix, x2, y2, z2, x1, y2, z2, r, g, b, a);
        drawLine(consumer, matrix, x1, y2, z2, x1, y2, z1, r, g, b, a);
        
        drawLine(consumer, matrix, x1, y1, z1, x1, y2, z1, r, g, b, a);
        drawLine(consumer, matrix, x2, y1, z1, x2, y2, z1, r, g, b, a);
        drawLine(consumer, matrix, x2, y1, z2, x2, y2, z2, r, g, b, a);
        drawLine(consumer, matrix, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }
    
    private static void drawLine(class_4588 consumer, Matrix4f matrix,
                                 float x1, float y1, float z1, float x2, float y2, float z2,
                                 float r, float g, float b, float a) {
        consumer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, a);
        consumer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, a);
    }
}
