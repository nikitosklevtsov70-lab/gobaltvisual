package com.example.gobaltvisual.utils;

import net.minecraft.class_243;

public class MathUtils {
    /**
     * Вычисляет расстояние между двумя точками в 3D
     */
    public static double distance(class_243 a, class_243 b) {
        return Math.sqrt(Math.pow(a.field_1352 - b.field_1352, 2) + Math.pow(a.field_1351 - b.field_1351, 2) + Math.pow(a.field_1350 - b.field_1350, 2));
    }

    /**
     * Линейная интерполяция
     */
    public static double lerp(double start, double end, double t) {
        return start + (end - start) * t;
    }

    /**
     * Ограничивает значение в диапазоне [min, max]
     */
    public static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    /**
     * Проверяет, находится ли точка внутри сферы
     */
    public static boolean isInsideSphere(class_243 center, double radius, class_243 point) {
        return distance(center, point) <= radius;
    }
}