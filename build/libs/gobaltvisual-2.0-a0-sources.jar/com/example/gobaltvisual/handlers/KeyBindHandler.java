package com.example.gobaltvisual.handlers;

import com.example.gobaltvisual.gui.GobaltVisualScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KeyBindHandler {
    private static class_304 openMenuKey;

    public static void register() {
        // Клавиша P
        openMenuKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.gobaltvisual.openmenu",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_P,
            "category.gobaltvisual"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Открытие по P
            while (openMenuKey.method_1436()) {
                if (client.field_1755 == null) {
                    System.out.println("[GV] Открываем меню по клавише P");
                    client.method_1507(new GobaltVisualScreen());
                }
            }

            // Открытие по правому Shift
            if (client.field_1755 == null && client.field_1690 != null) {
                if (GLFW.glfwGetKey(client.method_22683().method_4490(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS) {
                    System.out.println("[GV] Открываем меню по правому Shift");
                    client.method_1507(new GobaltVisualScreen());
                    // Небольшая задержка, чтобы не открывалось несколько раз
                    try { Thread.sleep(100); } catch (Exception ignored) {}
                }
            }
        });
    }
}
